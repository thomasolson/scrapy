# -*- coding: utf-8 -*-
import scrapy
from scrapy.spider import BaseSpider
from scrapy.selector import Selector
from pricing.items import PricingItem


class ScraperSpider(scrapy.Spider):
    name = "scraper"
    allowed_domains = ["www.homedepot.com"]
    start_urls = ["http://www.homedepot.com/s/whirlpool?NCNI-5"]

    def parse(self, response):
    	for sku in response.css('div.plp-pod'):
    		yield {
    		'model' : sku.css('div.pod-plp__model::text').extract_first(),
    		'price' : sku.css('div.price__wrapper > div:nth-child(1) > span::text').extract_first()
    		}

    	next_page = response.css('#plp_core > div:nth-child(5) > div > nav > ul > li.hd-pagination__item.hd-pagination__button > a::attr(href)').extract()
    	if next_page is not None:
    		next_page = response.urljoin(next_page)
    		yield scrapy.Request(next_page, callback=self.parse)




    	