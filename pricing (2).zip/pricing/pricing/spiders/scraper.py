# -*- coding: utf-8 -*-
import scrapy

class ScraperSpider(scrapy.Spider):
    name = "scraper"
    allowed_domains = ["www.homedepot.com"]
    start_urls = ["http://www.homedepot.com/s/whirlpool?NCNI-5"]

    def parse(self, response):
    	number = 0
    	for sku in response.css('div.plp-pod'):
    		yield {
    		'model' : sku.css('div.pod-plp__model::text').extract_first(),
    		'price' : sku.css('div.price__wrapper > div:nth-child(1) > span::text').extract_first()
    		}

    	if number == 0:	
    		next = response.css('li.hd-pagination__item.hd-pagination__button > a::attr(href)').extract_first()
    		print(next)
    		if next is not None:
    			next = response.urljoin(next)
    			number = 1
    			yield scrapy.Request(next, callback=self.parse)

    	if number == 1:
    		next = response.css('#plp_core > div:nth-child(5) > div > nav > ul > li:nth-child(7) > a::attr(href)').extract_first()
    		print(next)
    		if next is not None:
    			next = response.urljoin(next)
    			number = 1
    			yield scrapy.Request(next, callback=self.parse)